#!/usr/bin/env ruby
# frozen_string_literal: true

require 'uri'
require 'net/http'
require 'json'

require_relative '../../skill-add/scripts/install_from_zip'

class BuiltinSkillsInstaller
  PRIMARY_HOST     = ENV.fetch('OCTO_LICENSE_SERVER', 'https://www.octo.com')
  FALLBACK_HOST    = 'https://octo.up.railway.app'
  API_HOSTS        = ENV['OCTO_LICENSE_SERVER'] ? [PRIMARY_HOST] : [PRIMARY_HOST, FALLBACK_HOST]
  API_PATH         = '/api/v1/skills/builtin'
  API_OPEN_TIMEOUT = 5
  API_READ_TIMEOUT = 10

  def initialize
    @target_dir       = File.join(Dir.home, '.octo', 'skills')
    @installed        = 0
    @skipped_existing = 0
    @attempted        = 0
    @errors           = []
  end

  def run
    skills = fetch_skill_list
    if skills.nil? || skills.empty?
      emit_summary
      return
    end

    skills.each { |skill| install_one(skill) }
  ensure
    emit_summary
  end

  private def fetch_skill_list
    API_HOSTS.each do |host|
      begin
        uri = URI.parse(host + API_PATH)
        Net::HTTP.start(uri.host, uri.port,
                        use_ssl:      uri.scheme == 'https',
                        open_timeout: API_OPEN_TIMEOUT,
                        read_timeout: API_READ_TIMEOUT) do |http|
          response = http.request(Net::HTTP::Get.new(uri.request_uri))
          if response.code.to_i == 200
            payload = JSON.parse(response.body)
            return Array(payload['skills'])
          else
            @errors << "API #{host}: HTTP #{response.code}"
          end
        end
      rescue StandardError => e
        @errors << "API #{host}: #{e.class}: #{e.message}"
      end
    end
    nil
  end

  private def install_one(skill)
    name         = skill['name'].to_s
    download_url = skill['download_url'].to_s
    @attempted  += 1

    if name.empty? || download_url.empty?
      @errors << "skill payload missing name or download_url: #{skill.inspect}"
      return
    end

    result = ZipSkillInstaller.new(
      download_url,
      skill_name:     name,
      target_dir:     @target_dir,
      skip_if_exists: true
    ).perform
    @installed        += result[:installed].size
    @skipped_existing += result[:skipped].size
    @errors.concat(result[:errors]) if result[:errors].any?
  rescue StandardError => e
    @errors << "#{name}: #{e.class}: #{e.message}"
  end

  private def emit_summary
    unless @errors.empty?
      warn '[install_builtin_skills] non-fatal errors:'
      @errors.each { |e| warn "  - #{e}" }
    end
    puts JSON.generate(
      installed:        @installed,
      attempted:        @attempted,
      skipped_existing: @skipped_existing
    )
  end
end

BuiltinSkillsInstaller.new.run if __FILE__ == $0
