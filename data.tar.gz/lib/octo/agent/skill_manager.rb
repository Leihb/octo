# frozen_string_literal: true

module Octo
  class Agent
    # Skill management and execution
    # Handles skill loading, command parsing, and subagent execution
    module SkillManager
      # Load all skills from configured locations
      # @return [Array<Skill>]
      def load_skills
        @skill_loader.load_all
      end

      # Parse a slash command input and resolve the matching skill.
      #
      # Returns a result hash in all cases so the caller can act on the specific outcome:
      #
      #   { matched: false }                          — input is not a slash command
      #   { matched: true, found: false,
      #     skill_name: "xxx", reason: :not_found }   — /xxx but no skill registered
      #   { matched: true, found: false,
      #     skill_name: "xxx",
      #     reason: :not_user_invocable, skill: }     — skill exists but blocks direct invocation
      #   { matched: true, found: false,
      #     skill_name: "xxx",
      #     reason: :agent_not_allowed, skill: }      — skill not allowed for current agent profile
      #   { matched: true, found: true,
      #     skill_name: "xxx",
      #     skill:, arguments: }                      — success
      #
      # @param input [String] Raw user input
      # @return [Hash]
      def parse_skill_command(input)
        return { matched: false } unless input.is_a?(String) && input.start_with?("/")

        # Split off the first whitespace-delimited token after the leading "/".
        # Shape of a slash command:
        #   /<command>
        #   /<command> <arguments...>
        #
        # The key distinction we need to make is "slash command" vs. "filesystem
        # path starting with /". Paths look like "/xxx/yyy", "/Users/alice/foo",
        # "/tmp/bar" — what they all share is a *second* "/" inside the first
        # token. Slash commands, on the other hand, may legitimately contain
        # non-slug characters like ':' or '.' (e.g. "/guizang-ppt-skill:create"),
        # so we deliberately DO NOT require the command to be a clean slug here —
        # find_by_command handles the lookup, and a pilot-error like "/foo.bar"
        # should still surface a friendly "skill not found" notice.
        #
        # Rejected as slash commands (treated as plain user messages):
        #   - "/", "//", "/*.rb"        — token is empty or begins with a separator/glob
        #   - "/ leading space"         — whitespace immediately after /
        #   - "/Users/alice/foo"        — second "/" inside the first token ⇒ a path
        #   - "/xxxx/zzzz/"             — same
        #
        # Accepted (routed to find_by_command, may yield :not_found notice):
        #   - "/commit"
        #   - "/skill-add https://…"     — "/" appears only in arguments, fine
        #   - "/guizang-ppt-skill:create", "/foo.bar"  — non-slug but no path shape
        match = input.match(%r{^/(\S+?)(?:\s+(.*))?$})
        return { matched: false } unless match

        skill_name = match[1]
        arguments  = match[2] || ""

        # Reject path-like first tokens: anything containing a "/" after the
        # leading one belongs to the filesystem, not the command namespace.
        # This also naturally rejects "" (from "/" alone) and "*…" / ".…" style
        # tokens because they won't be registered as a command — but those edge
        # cases fall through to :not_found which is acceptable. The main goal is
        # to stop pasted paths like "/Users/foo/bar" from producing a bogus
        # "skill /Users/foo/bar not found" reply.
        return { matched: false } if skill_name.include?("/")
        return { matched: false } if skill_name.empty?

        skill = @skill_loader.find_by_command("/#{skill_name}")
        return { matched: true, found: false, skill_name: skill_name, reason: :not_found } unless skill

        unless skill.user_invocable?
          return { matched: true, found: false, skill_name: skill_name, reason: :not_user_invocable, skill: skill }
        end

        if @agent_profile && !skill.allowed_for_agent?(@agent_profile.name)
          return { matched: true, found: false, skill_name: skill_name, reason: :agent_not_allowed, skill: skill }
        end

        { matched: true, found: true, skill_name: skill_name, skill: skill, arguments: arguments }
      end

      # Maximum number of skills injected into the system prompt.
      # Keeps context tokens bounded regardless of how many skills are installed.
      MAX_CONTEXT_SKILLS = 30

      # Process-wide deduper for the "skill context limit" warning so that
      # every newly constructed Agent (sub-agents, retries, web turns…) doesn't
      # re-emit the same line.
      @skill_limit_warned_signatures = {}
      @skill_limit_warn_mutex = Mutex.new

      def self.warn_skill_limit_once(signature, &block)
        @skill_limit_warn_mutex.synchronize do
          return if @skill_limit_warned_signatures[signature]
          @skill_limit_warned_signatures[signature] = true
        end
        block.call
      end

      # Generate skill context - loads all auto-invocable skills allowed by the agent profile
      # @return [String] Skill context to add to system prompt
      def build_skill_context
        # Load all auto-invocable skills, filtered by the agent profile's skill whitelist.
        # Invalid skills (bad slug / unrecoverable metadata) are excluded from the system
        # prompt — they can't be invoked and should not clutter the context.
        all_skills = @skill_loader.load_all
        all_skills = filter_skills_by_profile(all_skills)
        all_skills = all_skills.reject(&:invalid?)
        auto_invocable = all_skills.select(&:model_invocation_allowed?)

        # Enforce system prompt injection limit to control token usage.
        # Warn at most once per process per dropped-set signature — build_skill_context
        # runs on every system-prompt assembly and is invoked from many short-lived
        # Agent instances (sub-agents, web turns…), so per-instance dedup wasn't enough.
        if auto_invocable.size > MAX_CONTEXT_SKILLS
          kept    = auto_invocable.first(MAX_CONTEXT_SKILLS)
          dropped = auto_invocable.drop(MAX_CONTEXT_SKILLS)
          dropped_names = dropped.map(&:identifier)
          signature = dropped_names.sort.join(",")

          SkillManager.warn_skill_limit_once(signature) do
            Octo::Logger.warn(
              "Skill context limit: #{auto_invocable.size} auto-invocable skills found, " \
              "only injecting first #{MAX_CONTEXT_SKILLS} " \
              "(#{dropped.size} dropped — will NOT be auto-discovered by the agent: " \
              "#{dropped_names.join(", ")}). " \
              "Remove unused skills to restore full visibility."
            )
          end
          auto_invocable = kept
        end

        return "" if auto_invocable.empty?

        context = "\n\n" + "=" * 80 + "\n"
        context += "AVAILABLE SKILLS:\n"
        context += "=" * 80 + "\n\n"
        context += "CRITICAL SKILL USAGE RULES:\n"
        context += "- When user's request matches a skill description, you MUST use invoke_skill tool — invoke only the single BEST matching skill, do NOT call multiple skills for the same request\n"
        context += "- Example: invoke_skill(skill_name: 'xxx', task: 'xxx')\n"
        context += "\n"
        context += "Available skills:\n\n"

        auto_invocable.each do |skill|
          context += "- name: #{skill.identifier}\n"
          context += "  description: #{skill.context_description}\n\n"
        end

        context += "\n"
        context
      end

      # Inject a synthetic assistant message containing the skill content for slash
      # commands (e.g. /pptx, /onboard).
      #
      # When a user types "/skill-name [arguments]", we immediately expand the skill
      # content and inject it as an assistant message so the LLM receives the full
      # instructions and acts on them — no waiting for the LLM to discover and call
      # invoke_skill on its own.
      #
      # When the slash command does not match any registered skill, a system message
      # is injected instructing the LLM to inform the user in their own language and
      # suggest similar skills — no error is raised, the LLM handles the reply.
      #
      # @param user_input [String] Raw user input
      # @param task_id [Integer] Current task ID (for message tagging)
      # @return [void]
      def inject_skill_command_as_assistant_message(user_input, task_id)
        result = parse_skill_command(user_input)

        # Not a slash command at all — nothing to do
        return unless result[:matched]

        skill_name = result[:skill_name]

        # Slash command recognised but skill could not be dispatched — inject an
        # LLM-facing notice so the model explains the situation to the user in
        # their own language instead of silently ignoring the command.
        unless result[:found]
          notice = case result[:reason]
          when :not_found
            suggestions = suggest_similar_skills(skill_name)
            msg = "[SYSTEM] The user entered the slash command /#{skill_name} but no matching skill was found. " \
                  "Please inform the user in their language that this skill does not exist."
            msg += " Suggest they try one of these similar skills: #{suggestions.map { |s| "/#{s}" }.join(", ")}." if suggestions.any?
            msg
          when :not_user_invocable
            "[SYSTEM] The user entered the slash command /#{skill_name} but this skill cannot be invoked directly via slash command. " \
            "Please inform the user in their language that this skill is only available through the AI assistant automatically."
          when :agent_not_allowed
            "[SYSTEM] The user entered the slash command /#{skill_name} but this skill is not available in the current context. " \
            "Please inform the user in their language that this skill is not enabled for the current session."
          end
          notice += " Do not attempt to execute any skill or tool. Just explain the situation clearly and helpfully."

          @history.append({ role: "assistant", content: notice, task_id: task_id, system_injected: true })
          @history.append({ role: "user", content: "[SYSTEM] Please respond to the user about the skill issue now.", task_id: task_id, system_injected: true })
          return
        end

        skill     = result[:skill]
        arguments = result[:arguments]

        # fork_agent skills run in an isolated subagent
        if skill.fork_agent?
          execute_skill_with_subagent(skill, arguments)
          return
        end

        inject_skill_as_assistant_message(skill, arguments, task_id, slash_command: true)
      end

      # Core injection logic: expand skill content and insert as synthetic assistant + user messages.
      #
      # Used by both the slash command path (inject_skill_command_as_assistant_message)
      # and the invoke_skill tool path (InvokeSkill#execute), so all skills go through
      # a single unified injection pipeline.
      #
      # Message structure after injection:
      #   assistant: "[expanded skill content]"    ← system_injected (skill instructions)
      #   user:      "[SYSTEM] Please proceed..."  ← system_injected (Claude compat shim)
      #
      # For encrypted skills, both messages are marked transient: true so they
      # are excluded from session.json serialization — the LLM sees the content during
      # the current session but it is never persisted to disk.
      #
      # @param skill [Skill] The skill to inject
      # @param arguments [String] Arguments / task description for the skill
      # @param task_id [Integer] Current task ID (for message tagging)
      # @return [void]
      def inject_skill_as_assistant_message(skill, arguments, task_id, slash_command: false)
        # Track skill execution context for self-evolution system
        @skill_execution_context = {
          skill_name: skill.identifier,
          start_iteration: @iterations,
          arguments: arguments,
          slash_command: slash_command,
          source: skill.source
        }

        # Expand skill content (template variables, supporting files)
        expanded_content = skill.process_content(template_context: build_template_context)

        # When triggered via slash command, prepend a notice so the LLM knows
        # invoke_skill has already been executed — preventing a second invocation.
        if slash_command
          expanded_content = "[SYSTEM] The skill '#{skill.identifier}' has been automatically invoked via slash command. " \
                             "Do NOT call invoke_skill again for this request. " \
                             "The skill instructions are as follows:\n\n" + expanded_content
        end

        @history.append({
          role: "assistant",
          content: expanded_content,
          task_id: task_id,
          system_injected: true
        })

        # Append a synthetic user message to keep the conversation sequence valid for
        # strict providers like Claude (Anthropic API), which require alternating
        # user/assistant turns. Without this shim the next real LLM call would find an
        # assistant message at the tail of the history, causing a 400 error.
        @history.append({
          role: "user",
          content: "[SYSTEM] The skill instructions above have been loaded. Please proceed to execute the task now.",
          task_id: task_id,
          system_injected: true
        })

        @ui&.show_info("Injected skill content for /#{skill.identifier}#{skill.name_zh.to_s.empty? ? "" : " (#{skill.name_zh})"}")
      end


      # Find skills whose identifiers are similar to the given name.
      # Uses substring matching first, then character overlap as a fallback.
      # Returns up to 3 suggestions sorted by relevance.
      # @param name [String] The unrecognized skill name from the slash command
      # @return [Array<String>] List of similar skill identifiers (slash-command safe)
      private def suggest_similar_skills(name)
        all = @skill_loader.all_skills.select(&:user_invocable?).map(&:identifier)
        query = name.downcase

        # Score each skill: substring match scores highest, then character overlap
        scored = all.filter_map do |id|
          id_lower = id.downcase
          score = if id_lower.include?(query) || query.include?(id_lower)
            2
          else
            # Count shared characters as a rough similarity measure
            common = (query.chars & id_lower.chars).size
            common > 0 ? 1 : nil
          end
          [id, score] if score
        end

        scored.sort_by { |_, s| -s }.first(3).map(&:first)
      end

      # Filter skills by the agent profile name using the skill's own `agent:` field.
      # Each skill declares which agents it supports via its frontmatter `agent:` field.
      # If the skill has no `agent:` field (defaults to "all"), it is allowed everywhere.
      # If no agent profile is set, all skills are allowed (backward-compatible).
      # @param skills [Array<Skill>]
      # @return [Array<Skill>]
      def filter_skills_by_profile(skills)
        return skills unless @agent_profile

        skills.select { |skill| skill.allowed_for_agent?(@agent_profile.name) }
      end

      # Build template context for skill content expansion.
      # Provides named values that can be used as <%= key %> in SKILL.md files.
      # Values are lazy Procs to avoid expensive computation unless actually needed.
      # @return [Hash<String, Proc>]
      def build_template_context
        {
          "memories_meta" => -> { load_memories_meta }
        }
      end

      # Scan ~/.octo/memories/ and return a formatted summary of all memory files.
      # Parses YAML frontmatter (same pattern as Skill#parse_frontmatter) for each file.
      # @return [String] Formatted list of memory topics and descriptions
      def load_memories_meta
        memories_dir = memories_base_dir
        return "(No long-term memories found.)" unless Dir.exist?(memories_dir)

        files = Dir.glob(File.join(memories_dir, "*.md"))
                    .sort_by { |f| File.mtime(f) }
                    .reverse
                    .first(20)
        return "(No long-term memories found.)" if files.empty?

        lines = ["Available memory files in ~/.octo/memories/:"]
        lines << ""

        files.each do |path|
          filename = File.basename(path)
          fm = parse_memory_frontmatter(path)
          topic       = fm["topic"]       || filename.sub(/\.md$/, "")
          description = fm["description"] || "(no description)"
          # Use file mtime as the "last seen" signal (covers both writes and
          # touch-on-recall LRU bumps). Authoritative — no longer relies on
          # an LLM-maintained `updated_at` frontmatter field.
          last_seen = File.mtime(path).strftime("%Y-%m-%d")

          entry = "- **#{filename}** | topic: #{topic} | #{description}"
          entry += " | last seen: #{last_seen}"
          lines << entry
        end

        lines.join("\n")
      end

      # Base directory for long-term memories. Override in tests for isolation.
      # @return [String]
      def memories_base_dir
        File.expand_path("~/.octo/memories")
      end

      # Parse YAML frontmatter from a memory file.
      # Returns empty hash if no frontmatter found or parsing fails.
      # @param path [String] Absolute path to the .md file
      # @return [Hash]
      def parse_memory_frontmatter(path)
        content = File.read(path)
        return {} unless content.start_with?("---")

        match = content.match(/\A---\n(.*?)\n---/m)
        return {} unless match

        YAML.safe_load(match[1]) || {}
      rescue => e
        {}
      end

      # Shred a directory containing decrypted brand skill scripts.
      # Overwrites each file with zeros before deletion to hinder recovery.
      # @param dir [String] Absolute path to the directory
      def shred_directory(dir)
        return unless dir && Dir.exist?(dir)

        Dir.glob(File.join(dir, "**", "*")).each do |f|
          next if File.directory?(f)
          size = File.size(f)
          File.open(f, "wb") { |io| io.write("\0" * size) } rescue nil
          File.unlink(f) rescue nil
        end
        FileUtils.remove_dir(dir, true) rescue nil
      end

      # Execute a skill in a forked subagent
      # @param skill [Skill] The skill to execute
      # @param arguments [String] Arguments for the skill
      # @return [String] Summary of subagent execution
      def execute_skill_with_subagent(skill, arguments)
        # Build skill role/constraint instructions only — do NOT substitute $ARGUMENTS here.
        # The actual task is delivered as a clean user message via subagent.run(arguments),
        # which arrives *after* the assistant acknowledgement injected by fork_subagent.
        # This gives the subagent a clear 3-part structure:
        #   [user] role/constraints  →  [assistant] acknowledgement  →  [user] actual task
        skill_instructions = skill.process_content(template_context: build_template_context)

        # Fork subagent with skill configuration
        subagent = fork_subagent(
          model: skill.subagent_model,
          forbidden_tools: skill.forbidden_tools_list,
          system_prompt_suffix: skill_instructions
        )

        # Log which model the subagent is actually using (may differ from requested
        # when "lite" falls back to default due to no lite model configured)
        @ui&.show_info("Subagent start: #{skill.identifier}#{skill.name_zh.to_s.empty? ? "" : " (#{skill.name_zh})"} [#{subagent.current_model_info[:model]}]")

        # Run subagent with the actual task as the sole user turn.
        # If the user typed the skill command with no arguments (e.g. "/jade-appraisal"),
        # use a generic trigger phrase so the user message is never empty.
        task_input = arguments.to_s.strip.empty? ? "Please proceed." : arguments

        begin
          result = subagent.run(task_input)
        rescue Octo::AgentInterrupted
          # Subagent was interrupted by user (Ctrl+C).
          # Write an interrupted summary into history so the parent agent's history
          # has a clean tool result — prevents a dangling tool_call with no tool_result
          # which would confuse the LLM on the next user message.
          interrupted_summary = "[Subagent '#{skill.identifier}' was interrupted by the user before completing.]"
          @history.mutate_last_matching(->(m) { m[:subagent_instructions] }) do |m|
            m[:content] = interrupted_summary
            m.delete(:subagent_instructions)
            m[:subagent_result] = true
            m[:skill_name] = skill.identifier
            m[:interrupted] = true
          end

          raise  # Re-raise so parent agent also exits cleanly
        end

        # Generate summary
        summary = generate_subagent_summary(subagent)

        # Mutate the subagent_instructions message in-place to become the result summary
        @history.mutate_last_matching(->(m) { m[:subagent_instructions] }) do |m|
          m[:content] = summary
          m.delete(:subagent_instructions)
          m[:subagent_result] = true
          m[:skill_name] = skill.identifier
        end

        # Merge subagent cost into parent agent's total so the sessionbar reflects
        # the real cumulative spend across all subagents
        subagent_cost = result[:total_cost_usd] || 0.0
        @total_cost += subagent_cost
        @ui&.update_sessionbar(cost: @total_cost, cost_source: @cost_source)

        # Log completion
        @ui&.show_info("Subagent completed: #{result[:iterations]} iterations, $#{subagent_cost.round(4)} (total: $#{@total_cost.round(4)})")

        # Return summary as the skill execution result
        summary
      end
    end
  end
end
